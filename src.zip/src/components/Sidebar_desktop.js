import React from "react";

const Sidebar_desktop = () => {
  return (
    <div className="  ">
      <ul className="bg-gradient-to-b hidden sm:flex w-64 -top-10 md:flex flex-col  from-[#0EBBA0] space-y-4 to-[#065549]  text-white">
        <hr />
        <li className="text-center p-2 hover:cursor-pointer text-sm font-semibold ">
          Blogs
        </li>
        <hr className="border-white" />
        <li className="text-center p-2 hover:cursor-pointer text-sm font-semibold ">
          Career Advice
        </li>
        <hr className="border-white" />
        <li className="text-center p-2 hover:cursor-pointer ">
          Success Stories
        </li>
        <hr className="border-white" />
        <li className="text-center p-2 hover:cursor-pointer text-sm font-semibold ">
          Community Forum
        </li>
        <hr className="border-white" />
        <li className="text-center p-2 hover:cursor-pointer text-sm font-semibold ">
          Community Forum
        </li>
        <hr className="border-white" />
        <li className="text-center p-2 hover:cursor-pointer text-sm font-semibold ">
          Community Forum
        </li>
        <hr className="border-white" />
        <li className="text-center p-2 hover:cursor-pointer text-sm font-semibold ">
          Community Forum
        </li>
        <hr className="border-white" />
        <li className="text-center p-2 hover:cursor-pointer text-sm font-semibold ">
          Community Forum
        </li>
        <hr className="border-white" />
        <li className="text-center p-2 hover:cursor-pointer text-sm font-semibold ">
          Help
        </li>
      </ul>
    </div>
  );
};

export default Sidebar_desktop;
